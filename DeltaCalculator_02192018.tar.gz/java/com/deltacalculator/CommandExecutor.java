package com.deltacalculator;

import org.gbif.dwca.io.ArchiveFile;

import java.io.*;

import static com.deltacalculator.DeltaCalculator.DWCADiff;

public class CommandExecutor {
    void removeDirectory(String directory) throws IOException, InterruptedException {
        System.out.println("Removing Directory: "+directory);
        Process removeDir = Runtime.getRuntime().exec("rm -r "+directory);
        removeDir.waitFor();
    }

    void compress(File dwcaDiff) throws IOException, InterruptedException {
        System.out.println("Compressing Archive: "+dwcaDiff.getName());
        Process compress = Runtime.getRuntime().exec("tar -czf "+dwcaDiff.getName()+".tar.gz"+" "+dwcaDiff.getName());
        compress.waitFor();
    }

    public File executeDiff (String file1, String file2, ArchiveFile archiveFile) throws IOException, InterruptedException {
        ArchiveFileHandler archiveFileHandler = new ArchiveFileHandler();
        String file1SDIFF = file1,
               file2SDIFF = file2;
        System.out.println("Comparing Files: "+file1+", "+file2);
        if(!DWCADiff.exists())
            DWCADiff.mkdir();
        File diffFile=new File(DWCADiff+"/"+file2.substring(file2.indexOf("/")+1,file2.length()));
        if (!diffFile.exists())
            diffFile.createNewFile();

        if (file1.contains(" "))
            file1SDIFF = removeSpaceFromFileName(file1);
        if(file2.contains(" "))
            file2SDIFF = removeSpaceFromFileName(file2);

        System.out.println("before sdiff directly");

        Process sDiff = Runtime.getRuntime().exec("sdiff "+file1SDIFF+" "+ file2SDIFF+ " -s"+" -H"+" -w"+" 2048");

        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(sDiff.getInputStream()));
        System.out.println("After bufferedreader ");
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(diffFile));

        ActionFile actionFile = new ActionFile();
        int i = 0;
        String line = "",
                actionIndicator = "",
                outputLine = "",
                delimiter = archiveFile.getFieldsTerminatedBy();
        System.out.println("Before loop line is: " + line);

        while((line = bufferedReader.readLine())!=null){
            line = line.trim();
            if (file2.contains("common names"))
            System.out.println("Inside loop line is: " + line);
            if (line.startsWith(">")) {
                outputLine = archiveFileHandler.lineInsert(line);
                actionIndicator = actionFile.getActionIndicator(ActionFile.Action.Insert);
            }
            else if (line.endsWith("<")){
                outputLine = archiveFileHandler.lineDelete(line);
                actionIndicator = actionFile.getActionIndicator(ActionFile.Action.Delete);
            }
            else{
                outputLine = archiveFileHandler.lineUpdate(line);
                actionIndicator = actionFile.getActionIndicator(ActionFile.Action.Update);
            }
            bufferedWriter.write(outputLine);
            String recordId = actionFile.getRecordId(outputLine,delimiter, archiveFileHandler.getSortingColumnIndex(archiveFile));
            actionFile.writeLineToActionFile(archiveFile, recordId, delimiter, actionIndicator);
            ArchiveFileHandler.addIdToArrayList(archiveFile, recordId);
            i++;
        }

        System.out.println("i = " + i);
        bufferedReader.close();
        archiveFileHandler.commit(bufferedWriter);
        return diffFile;
    }

    private String removeSpaceFromFileName(String fileName) throws IOException {
        File oldFile = new File(fileName);
        String newFileName = fileName.replace(" ","_");
        File newFile = new File(newFileName);
        if(!newFile.exists())
            newFile.createNewFile();
        oldFile.renameTo(newFile);
        return newFileName;
    }

    public File executeSort (File inputFile, String archiveFileDelimiter, int[] sortingColumnIndex) throws IOException, InterruptedException {
        ExternalSort.delimiter = archiveFileDelimiter;
        ExternalSort.size = sortingColumnIndex.length;
        ExternalSort.sortingColumnIndex = sortingColumnIndex;
        System.out.println("Sorting File: "+inputFile.getPath());
        File outputFile = new File(inputFile.getPath());
        ExternalSort.sort(inputFile,outputFile);
        outputFile.renameTo(inputFile);
        return (outputFile);
    }
}