package com.deltacalculator;

import org.gbif.dwc.terms.Term;
import org.gbif.dwca.io.Archive;
import java.io.*;
import java.util.Date;
import java.util.Map;


public class DeltaCalculator {
static File DWCADiff=new File("DifferenceDynamicHierarchy_"+new Date().getTime());

        public DeltaCalculator() throws IOException {
        }

        public static void main(String[] args) throws IOException, InterruptedException {
        ArchiveHandler archiveHandler = new ArchiveHandler();
        ArchiveFileHandler archiveFileHandler = new ArchiveFileHandler();
        CommandExecutor commandExecutor = new CommandExecutor();
        if(!DWCADiff.exists())
            DWCADiff.mkdir();
        File archiveVersion1 = new File("indianocean3.tar.gz"),
             archiveVersion2 = new File("indianocean4.tar.gz");
        String archive1Path = archiveVersion1.getName(),
               archive2Path = archiveVersion2.getName();
        Archive dwca1 = archiveHandler.openDwcAFolder(archive1Path),
                dwca2 = archiveHandler.openDwcAFolder(archive2Path);
        System.out.println(dwca1.getMetadataLocation());
        System.out.println(dwca2.getMetadataLocation());
        File metaFile = new File (dwca2.getLocation().getName()+"/"+dwca2.getMetadataLocationFile().getName());
        if(!dwca2.getMetadataLocation().equals(null)) {
            System.out.println("Meta File Found - Sending File: " + metaFile.getPath());
            archiveFileHandler.copyMetaFile(metaFile, DWCADiff.getName());
        }

        archiveHandler.filterContent(dwca1,dwca2);
        commandExecutor.removeDirectory(dwca1.getLocation().getName());
        commandExecutor.removeDirectory(dwca2.getLocation().getName());
        Archive updatedArchive = archiveHandler.openDwcAFolder(archive2Path);
        adjustUnchangedRecords(updatedArchive);
        commandExecutor.compress(DWCADiff);
        commandExecutor.removeDirectory(DWCADiff.getName());
        }

        private static void adjustUnchangedRecords(Archive updatedArchive) {
                ArchiveFileHandler.setMediaOfChangedAgents(updatedArchive);
                ArchiveFileHandler.setMediaOfChangedReference(updatedArchive);

                ArchiveFileHandler.setMeasurementOfChangedReference(updatedArchive);
                ArchiveFileHandler.setAssociationOfChangedReference(updatedArchive);

                ArchiveFileHandler.setOccurrenceOfChangedMeasurements(updatedArchive);
                ArchiveFileHandler.setOccurrenceOfChangedAssociations(updatedArchive);

                ArchiveFileHandler.setTaxaOfChangedMedia(updatedArchive);
                ArchiveFileHandler.setTaxaOfChangedOccurrences(updatedArchive);
                ArchiveFileHandler.setTaxaOfChangedReference(updatedArchive);
                ArchiveFileHandler.setTaxaOfChangedVernacular(updatedArchive);
        }
}