package com.deltacalculator;

import org.apache.commons.lang3.StringUtils;
import org.gbif.dwc.terms.DwcTerm;
import org.gbif.dwc.terms.Term;
import org.gbif.dwca.io.Archive;
import org.gbif.dwca.io.ArchiveField;
import org.gbif.dwca.io.ArchiveFile;
import org.bibalex.utils.*;
import org.gbif.dwca.record.Record;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;


public class ArchiveFileHandler {
    Map<Term, Term> rowTypeId = setRowTypeId();

    public ArchiveFileHandler() throws IOException {
    }

    void copyMetaFile(File metaFile, String archivePathName) throws IOException {
        File targetMetaFile = new File(archivePathName + "/" + metaFile.getName());
        if (!targetMetaFile.exists())
            Files.copy(metaFile.toPath(), targetMetaFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    public String getHeader(File file) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file.getPath()));
        String fileHeader = bufferedReader.readLine();
        return (fileHeader);
    }

    public File addHeader(File file, String header) throws IOException {
        File temp = new File(file.getPath() + "temp");
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(temp, true));
        bufferedWriter.write(header + "\n");
        String line = bufferedReader.readLine();
        while (line != null)
        {
            bufferedWriter.write(line + "\n");
            line = bufferedReader.readLine();
        }
        commit(bufferedWriter);
        temp.renameTo(file);
        return (temp);
    }

    public void commit(BufferedWriter bufferedWriter) throws IOException {
        bufferedWriter.flush();
        bufferedWriter.close();
    }

    public void readFromFileWriteToFile(File inputFile, boolean mode, String targetArchive, ArchiveFile archiveFile) throws IOException {
        BufferedReader readInput = new BufferedReader(new FileReader(inputFile));
        File outputFile = new File(targetArchive + "/" + inputFile.getName());
        String actionIndicator = "";
        if (!outputFile.exists())
            outputFile.createNewFile();

        ArchiveFileHandler archiveFileHandler = new ArchiveFileHandler();

        ActionFile actionFile = new ActionFile();

        BufferedWriter writeOutput = new BufferedWriter(new FileWriter(outputFile));
        String inputLine = "",
        delimiter = archiveFile.getFieldsTerminatedBy();
        while ((inputLine= readInput.readLine()) != null) {
            if (mode) {
                writeOutput.write(lineInsert(inputLine));
                actionIndicator = actionFile.getActionIndicator(ActionFile.Action.Insert);
            }
            else {
                writeOutput.write(lineDelete(inputLine));
                System.out.println("Deleted File Line: "+inputLine);
                actionIndicator = actionFile.getActionIndicator(ActionFile.Action.Delete);
            }
            String recordId = actionFile.getRecordId(inputLine,delimiter, archiveFileHandler.getSortingColumnIndex(archiveFile));
            actionFile.writeLineToActionFile(archiveFile, recordId, delimiter, actionIndicator);

        }
        commit(writeOutput);
    }

    public String lineInsert(String inputLine)
    {
        inputLine = inputLine.substring(1,inputLine.length());
        inputLine = inputLine.trim();
        if(!StringUtils.isBlank(inputLine))
        {
            String insertedLine = inputLine+"\n";
            return insertedLine;}
        else
            return ("");
    }
    public String lineDelete(String inputLine)
    {
        String deletedLine = inputLine.trim().substring(0,inputLine.length()-2)+"\n";
        return deletedLine;
    }
    public String lineUpdate(String inputLine)
    {
        String updatedLine = inputLine.substring(inputLine.indexOf('|')+1,inputLine.length()).trim()+"\n";
        return updatedLine;
    }

    void compareContent(Archive version1, Archive version2, ArrayList<Term> archiveRowTypesArrayList) throws IOException, InterruptedException {
        ArchiveFileHandler archiveFileHandler = new ArchiveFileHandler();
        CommandExecutor commandExecutor = new CommandExecutor();


        for (int i = 0; i < archiveRowTypesArrayList.size(); i++) {
            if(archiveRowTypesArrayList.get(i)!= DwcTerm.Taxon){
            ArchiveFile archiveFile1 = version1.getExtension(archiveRowTypesArrayList.get(i)),
                        archiveFile2 = version2.getExtension(archiveRowTypesArrayList.get(i));
            File file1 = new File(version1.getLocation().getName() + "/" + (archiveFile1.getTitle())),
                 file2 = new File(version2.getLocation().getName() + "/" + (archiveFile2.getTitle()));

            System.out.println(file1.getPath() + ", " + file2.getPath());
            String fileHeader = archiveFileHandler.getHeader(file2);

            File sortedFile1 = commandExecutor.executeSort(file1, (archiveFile1.getFieldsTerminatedBy()), getSortingColumnIndex(archiveFile1)),
                 sortedFile2 = commandExecutor.executeSort(file2, (archiveFile2.getFieldsTerminatedBy()), getSortingColumnIndex(archiveFile2)),
                 differenceFile = commandExecutor.executeDiff(sortedFile1.getPath(), sortedFile2.getPath(),archiveFile2);

            if ((version2.getExtension(archiveRowTypesArrayList.get(i)).getIgnoreHeaderLines()) == 1)
                archiveFileHandler.addHeader(differenceFile, fileHeader);
        }
        else {
                ArchiveFile archiveCoreFile1 = version1.getCore(),
                            archiveCoreFile2 = version2.getCore();
                File coreFile1 = new File(version1.getLocation().getName() + "/" + archiveCoreFile1.getTitle()),
                     coreFile2 = new File(version2.getLocation().getName() + "/" + archiveCoreFile2.getTitle());
                System.out.println("Core Files: "+coreFile1.getPath() + ", " + coreFile2.getPath());
                String fileHeader = archiveFileHandler.getHeader(coreFile2);

                File sortedFile1 = commandExecutor.executeSort(coreFile1, (archiveCoreFile1.getFieldsTerminatedBy()), getSortingColumnIndex(archiveCoreFile1)),
                        sortedFile2 = commandExecutor.executeSort(coreFile2, (archiveCoreFile2.getFieldsTerminatedBy()), getSortingColumnIndex(archiveCoreFile2)),
                        differenceFile = commandExecutor.executeDiff(sortedFile1.getPath(), sortedFile2.getPath(), (version2.getCore()));

                if ((archiveCoreFile2.getIgnoreHeaderLines()) == 1)
                    archiveFileHandler.addHeader(differenceFile, fileHeader);
            }
    }}

    Map<Term, Term> setRowTypeId() throws IOException {

        Map<Term, Term> rowTypeId = new HashMap<>();
        rowTypeId.put(CommonTerms.mediaTerm, CommonTerms.identifierTerm);
        rowTypeId.put(CommonTerms.occurrenceTerm, CommonTerms.occurrenceIDTerm);
        rowTypeId.put(CommonTerms.agentTerm, CommonTerms.identifierTerm);
        rowTypeId.put(CommonTerms.associationTerm, CommonTerms.associationIDTerm);
        rowTypeId.put(CommonTerms.referenceTerm, CommonTerms.identifierTerm);
        rowTypeId.put(DwcTerm.Taxon, DwcTerm.taxonID);
        rowTypeId.put(DwcTerm.MeasurementOrFact, DwcTerm.measurementID);
        return rowTypeId;
    }

    void setRowType(Archive archive) throws IOException {
        Map<Term, Term> rowTypeId = setRowTypeId();
        for (ArchiveFile archiveFile : archive.getExtensions()) {
            Term idTerm = rowTypeId.get(archiveFile.getRowType());
            List<ArchiveField> fieldsSorted = archiveFile.getFieldsSorted();
            ArrayList<Term> termsSorted = new ArrayList<Term>();
            for (ArchiveField archiveField : fieldsSorted) {
                termsSorted.add(archiveField.getTerm());
            }
            int index = termsSorted.indexOf(idTerm);
            ExternalSort.sortingColumnIndex = index;
            ExternalSort.delimiter = archiveFile.getFieldsTerminatedBy();
            System.out.println("Archive File: " + archiveFile.getTitle() + " - " + index);
        }
    }

    int getSortingColumnIndex(ArchiveFile archiveFile) throws IOException {
        Term idTerm = rowTypeId.get(archiveFile.getRowType());
        List<ArchiveField> fieldsSorted = archiveFile.getFieldsSorted();
        ArrayList<Term> termsSorted = new ArrayList<>();
        for (ArchiveField archiveField : fieldsSorted) {
            termsSorted.add(archiveField.getTerm());
        }
        return termsSorted.indexOf(idTerm);
    }

    public static void addIdToArrayList(ArchiveFile archiveFile, String id){
        ModelsIds modelsIds = ModelsIds.getModelsIds();
        if(archiveFile.getRowType().equals(CommonTerms.agentTerm)){
            System.out.println("add agent id "+id+"models ids "+modelsIds);
            modelsIds.addAgentId(id);
        }
    }

    public static void getMediaOfChangedAgents(Archive updatedArchive){
        HashSet<String> agentIds = ModelsIds.getModelsIds().getAgentIds();
        ArchiveFile mediaFile = updatedArchive.getExtension(CommonTerms.mediaTerm);
        for (Record record : mediaFile){
            System.out.println(record.toString());
            String [] recordAgents = record.value(CommonTerms.agentIDTerm).split(";");
            for(int i=0; i<recordAgents.length; i++){
                System.out.println("getMediaOfChangedAgents " +recordAgents[i]);
                if(agentIds.contains(recordAgents[i]))
                    ModelsIds.getModelsIds().addMediumId(record.value(CommonTerms.identifierTerm));
            }
        }
    }
}