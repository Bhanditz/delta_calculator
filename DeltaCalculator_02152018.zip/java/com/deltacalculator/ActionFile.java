package com.deltacalculator;

import org.gbif.dwca.io.ArchiveFile;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

import static com.deltacalculator.DeltaCalculator.DWCADiff;

public class ActionFile {
    public enum Action {
    Update,
    Insert,
    Delete,
    Unchanged}
    Map <Action, String> actionMap = loadActionMap();

    File writeLineToActionFile(ArchiveFile diffFile, String recordId, String delimiter, String actionIndicator) throws IOException {
        ArchiveFileHandler archiveFileHandler = new ArchiveFileHandler();
        File actionFile = new File (DWCADiff+"/"+diffFile.getTitle()+"_action");
        if (!actionFile.exists()) {
            actionFile.createNewFile();
        System.out.println("Action File Name: "+actionFile.getName());}
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(actionFile,true));
        String record = actionIndicator+delimiter+recordId+"\n";
//        System.out.println(record);
        bufferedWriter.write(record);
        archiveFileHandler.commit(bufferedWriter);
        return actionFile;
    }

    String getRecordId(String record, String delimiter, int sortingColumnIndex) throws IOException {
        String recordId = record.split(delimiter)[sortingColumnIndex];
        return recordId;
    }

    String getActionIndicator (Action action) {return actionMap.get(action);}

    Map<Action, String> loadActionMap()
    {
        Map<Action, String> actionMap = new HashMap<>();
        actionMap.put(Action.Update,"U");
        actionMap.put(Action.Insert,"I");
        actionMap.put(Action.Delete,"D");
        actionMap.put(Action.Unchanged,"N");
        return actionMap;
    }


}
