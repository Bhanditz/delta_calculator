package com.deltacalculator;

import java.util.ArrayList;
import java.util.HashSet;

public class ModelsIds {
    private static ModelsIds modelsIds= null;
    private HashSet<String> agentIds;
    private HashSet<String> mediaIds;
    private HashSet<String> taxaIds;

    private ModelsIds(){
        agentIds = new HashSet<>();
        mediaIds = new HashSet<>();
        taxaIds = new HashSet<>();
    }

    public static ModelsIds getModelsIds() {
        if (modelsIds == null)
            modelsIds = new ModelsIds();
        return modelsIds;
    }

    public HashSet<String> getAgentIds() {
        return agentIds;
    }

    public void addAgentId(String agentId) {
        agentIds.add(agentId);
    }

    public HashSet<String> getMediaIds() {
        return mediaIds;
    }

    public void addMediumId(String mediumId) {
        mediaIds.add(mediumId);
    }

    public HashSet<String> getTaxaIds() {
        return taxaIds;
    }

    public void addTaxaId(String taxaId) {
        taxaIds.add(taxaId);
    }
}
