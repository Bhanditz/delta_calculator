/**
 * The decision to keep Darwin Core extensions in this project (dwca-io) instead of dwc-api is deliberate.
 *
 */
package org.gbif.dwc.extensions;